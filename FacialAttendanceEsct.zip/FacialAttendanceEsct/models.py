from app import db
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

# User Roles
class Role:
    ADMIN = 'admin'
    LECTURER = 'lecturer'
    STUDENT = 'student'

# User Model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    first_name = db.Column(db.String(64), nullable=False)
    last_name = db.Column(db.String(64), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    student_info = db.relationship('Student', backref='user', uselist=False, cascade="all, delete-orphan")
    lecturer_info = db.relationship('Lecturer', backref='user', uselist=False, cascade="all, delete-orphan")
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def is_admin(self):
        return self.role == Role.ADMIN
    
    def is_lecturer(self):
        return self.role == Role.LECTURER
    
    def is_student(self):
        return self.role == Role.STUDENT

# Student Model
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    student_id = db.Column(db.String(20), unique=True, nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'), nullable=False)
    level = db.Column(db.Integer, nullable=False)  # 100, 200, 300, 400
    
    # Relationships
    department = db.relationship('Department', backref='students')
    attendance_records = db.relationship('Attendance', backref='student')
    face_data = db.relationship('FaceData', backref='student', uselist=False, cascade="all, delete-orphan")
    reports = db.relationship('MissedClassReport', backref='student', cascade="all, delete-orphan")

# Lecturer Model
class Lecturer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    staff_id = db.Column(db.String(20), unique=True, nullable=False)
    
    # Relationships
    courses = db.relationship('CourseAssignment', backref='lecturer')

# Department Model
class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    code = db.Column(db.String(10), unique=True, nullable=False)
    
    # Relationships
    courses = db.relationship('Course', backref='department')

# Course Model
class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), nullable=False)
    __table_args__ = (db.UniqueConstraint('code', 'department_id', name='unique_code_per_department'),)
    title = db.Column(db.String(200), nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'), nullable=False)
    level = db.Column(db.Integer, nullable=False)  # 100, 200, 300, 400
    semester = db.Column(db.Integer, nullable=False)  # 1 or 2
    is_general = db.Column(db.Boolean, default=False)  # True for general courses available to all departments
    
    # Relationships
    assignments = db.relationship('CourseAssignment', backref='course')
    attendance_sessions = db.relationship('AttendanceSession', backref='course', cascade="all, delete-orphan")

# Course Assignment Model
class CourseAssignment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    lecturer_id = db.Column(db.Integer, db.ForeignKey('lecturer.id'), nullable=False)
    academic_year = db.Column(db.String(20), nullable=False)
    
    # Relationships
    attendance_sessions = db.relationship('AttendanceSession', backref='assignment', cascade="all, delete-orphan")

# Attendance Session Model
class AttendanceSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    assignment_id = db.Column(db.Integer, db.ForeignKey('course_assignment.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    
    # Relationships
    attendance_records = db.relationship('Attendance', backref='session', cascade="all, delete-orphan")

# Attendance Model
class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('attendance_session.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    status = db.Column(db.Boolean, default=False)  # True = Present, False = Absent
    time_recorded = db.Column(db.DateTime, default=datetime.utcnow)
    modified = db.Column(db.Boolean, default=False)
    modified_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    modification_reason = db.Column(db.Text, nullable=True)
    
    # Relationship to track who modified the attendance
    modifier = db.relationship('User', foreign_keys=[modified_by])

# Face Data Model
class FaceData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    face_encoding_1 = db.Column(db.LargeBinary, nullable=False)
    face_encoding_2 = db.Column(db.LargeBinary, nullable=False)
    face_encoding_3 = db.Column(db.LargeBinary, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Missed Class Report Model
class MissedClassReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship
    course = db.relationship('Course')
