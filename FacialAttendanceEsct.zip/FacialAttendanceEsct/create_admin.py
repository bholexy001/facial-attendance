from flask import Flask
from app import app, db
from models import User, Role
import os

def create_admin_user():
    """Create an admin user if no admin users exist"""
    with app.app_context():
        # Check if any admin user exists
        admin_exists = User.query.filter_by(role=Role.ADMIN).first()
        
        if admin_exists:
            print("Admin user already exists. No action taken.")
            return
        
        # Create new admin user
        admin = User(
            username="admin",
            email="admin@esctuniversity.edu",
            first_name="Admin",
            last_name="User",
            role=Role.ADMIN
        )
        
        # Set password
        admin.set_password("adminpassword123")
        
        # Add to database
        db.session.add(admin)
        db.session.commit()
        
        print("Admin user created successfully!")
        print("Username: admin")
        print("Email: admin@esctuniversity.edu")
        print("Password: adminpassword123")
        print("\nPlease change the password after first login for security.")

if __name__ == "__main__":
    create_admin_user()