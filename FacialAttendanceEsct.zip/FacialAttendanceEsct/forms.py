from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, TextAreaField, DateField, TimeField, BooleanField, MultipleFileField, IntegerField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError, NumberRange
from flask_wtf.file import FileField, FileRequired, FileAllowed
from models import User, Department, Course, Student, Role
from datetime import datetime

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class AdminRegistrationForm(FlaskForm):
    first_name = StringField('First Name', validators=[DataRequired(), Length(min=2, max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(min=2, max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=25)])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8, message='Password must be at least 8 characters long')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    submit = SubmitField('Register Administrator')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different email.')
            
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already taken. Please choose a different one.')

class LecturerRegistrationForm(FlaskForm):
    first_name = StringField('First Name', validators=[DataRequired(), Length(min=2, max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(min=2, max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=25)])
    staff_id = StringField('Staff ID', validators=[DataRequired(), Length(min=2, max=20)])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8, message='Password must be at least 8 characters long')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    submit = SubmitField('Register Lecturer')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different email.')
            
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already taken. Please choose a different one.')
    
    def validate_staff_id(self, staff_id):
        from models import Lecturer
        lecturer = Lecturer.query.filter_by(staff_id=staff_id.data).first()
        if lecturer:
            raise ValidationError('Staff ID already registered. Please check and try again.')

class StudentRegistrationForm(FlaskForm):
    first_name = StringField('First Name', validators=[DataRequired(), Length(min=2, max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(min=2, max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=25)])
    student_id = StringField('Student ID', validators=[DataRequired(), Length(min=2, max=20)])
    department_id = SelectField('Department', coerce=int, validators=[DataRequired()])
    level = SelectField('Level', choices=[(100, '100'), (200, '200'), (300, '300'), (400, '400')], coerce=int, validators=[DataRequired()])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8, message='Password must be at least 8 characters long')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    face_photo_1 = FileField('Upload Face Photo 1', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png'], 'Images only!')
    ])
    face_photo_2 = FileField('Upload Face Photo 2', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png'], 'Images only!')
    ])
    face_photo_3 = FileField('Upload Face Photo 3', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png'], 'Images only!')
    ])
    submit = SubmitField('Register Student')
    
    def __init__(self, *args, **kwargs):
        super(StudentRegistrationForm, self).__init__(*args, **kwargs)
        self.department_id.choices = [(dept.id, dept.name) for dept in Department.query.order_by('name').all()]
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different email.')
            
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already taken. Please choose a different one.')
    
    def validate_student_id(self, student_id):
        student = Student.query.filter_by(student_id=student_id.data).first()
        if student:
            raise ValidationError('Student ID already registered. Please check and try again.')

class DepartmentForm(FlaskForm):
    name = StringField('Department Name', validators=[DataRequired(), Length(min=2, max=100)])
    code = StringField('Department Code', validators=[DataRequired(), Length(min=2, max=10)])
    submit = SubmitField('Add Department')
    
    def validate_code(self, code):
        department = Department.query.filter_by(code=code.data).first()
        if department:
            raise ValidationError('Department code already exists. Please use a different code.')
    
    def validate_name(self, name):
        department = Department.query.filter_by(name=name.data).first()
        if department:
            raise ValidationError('Department name already exists. Please use a different name.')

class CourseForm(FlaskForm):
    code = StringField('Course Code', validators=[DataRequired(), Length(min=2, max=20)])
    title = StringField('Course Title', validators=[DataRequired(), Length(min=2, max=200)])
    department_id = SelectField('Department', coerce=int, validators=[DataRequired()])
    level = SelectField('Level', choices=[(100, '100'), (200, '200'), (300, '300'), (400, '400')], coerce=int, validators=[DataRequired()])
    semester = SelectField('Semester', choices=[(1, 'First Semester'), (2, 'Second Semester')], coerce=int, validators=[DataRequired()])
    is_general = BooleanField('General Course (Available to all departments)')
    submit = SubmitField('Add Course')
    
    def __init__(self, *args, **kwargs):
        super(CourseForm, self).__init__(*args, **kwargs)
        self.department_id.choices = [(dept.id, dept.name) for dept in Department.query.order_by('name').all()]
    
    def validate_code(self, code):
        # Get course_id from request args if it exists (for edit mode)
        from flask import request
        course_id = request.args.get('edit', type=int)
        
        # Check if code exists but exclude the current course being edited
        course = Course.query.filter_by(code=code.data).first()
        if course and (not course_id or course.id != course_id):
            raise ValidationError('Course code already exists. Please use a different code.')

class CourseAssignmentForm(FlaskForm):
    course_id = SelectField('Course', coerce=int, validators=[DataRequired()])
    lecturer_id = SelectField('Lecturer', coerce=int, validators=[DataRequired()])
    academic_year = StringField('Academic Year (e.g., 2023/2024)', validators=[DataRequired(), Length(min=4, max=20)])
    submit = SubmitField('Assign Course')
    
    def __init__(self, *args, **kwargs):
        super(CourseAssignmentForm, self).__init__(*args, **kwargs)
        from models import Lecturer
        
        # Get all courses
        self.course_id.choices = [(course.id, f"{course.code} - {course.title} (Level: {course.level}, Sem: {course.semester})") 
                                 for course in Course.query.order_by('code').all()]
        
        # Get all lecturers
        self.lecturer_id.choices = []
        lecturers = Lecturer.query.all()
        for lecturer in lecturers:
            user = User.query.get(lecturer.user_id)
            if user:
                self.lecturer_id.choices.append((lecturer.id, f"{user.first_name} {user.last_name} ({lecturer.staff_id})"))

class TakeAttendanceForm(FlaskForm):
    course_assignment_id = SelectField('Course', coerce=int, validators=[DataRequired()])
    date = DateField('Date', validators=[DataRequired()], default=datetime.today)
    start_time = TimeField('Start Time', validators=[DataRequired()])
    end_time = TimeField('End Time', validators=[DataRequired()])
    submit = SubmitField('Start Attendance Session')
    
    def __init__(self, lecturer_id, *args, **kwargs):
        super(TakeAttendanceForm, self).__init__(*args, **kwargs)
        from models import CourseAssignment
        
        # Get courses assigned to this lecturer
        self.course_assignment_id.choices = []
        assignments = CourseAssignment.query.filter_by(lecturer_id=lecturer_id).all()
        for assignment in assignments:
            course = Course.query.get(assignment.course_id)
            if course:
                self.course_assignment_id.choices.append(
                    (assignment.id, f"{course.code} - {course.title} (Level: {course.level}, Sem: {course.semester})")
                )

class ModifyAttendanceForm(FlaskForm):
    status = BooleanField('Mark as Present')
    reason = TextAreaField('Reason for Modification', validators=[DataRequired(), Length(min=10)])
    submit = SubmitField('Update Attendance')

class ReportMissedClassForm(FlaskForm):
    course_id = SelectField('Course', coerce=int, validators=[DataRequired()])
    date = DateField('Date of Missed Class', validators=[DataRequired()], default=datetime.today)
    reason = TextAreaField('Reason for Missing Class', validators=[DataRequired(), Length(min=10)])
    submit = SubmitField('Submit Report')
    
    def __init__(self, student, *args, **kwargs):
        super(ReportMissedClassForm, self).__init__(*args, **kwargs)
        
        # Get all courses for this student's department and level
        # Including general courses available to all departments
        department_courses = Course.query.filter_by(
            department_id=student.department_id, 
            level=student.level
        ).all()
        
        general_courses = Course.query.filter_by(
            is_general=True,
            level=student.level
        ).all()
        
        # Combine and remove duplicates
        available_courses = department_courses + [
            course for course in general_courses 
            if course not in department_courses
        ]
        
        self.course_id.choices = [
            (course.id, f"{course.code} - {course.title}") 
            for course in sorted(available_courses, key=lambda c: c.code)
        ]

class SearchAttendanceForm(FlaskForm):
    student_name = StringField('Student Name', validators=[DataRequired(), Length(min=2)])
    department_id = SelectField('Department', coerce=int)
    level = SelectField('Level', choices=[(0, 'All'), (100, '100'), (200, '200'), (300, '300'), (400, '400')], 
                      coerce=int, default=0)
    course_id = SelectField('Course', coerce=int)
    date_from = DateField('From Date')
    date_to = DateField('To Date')
    submit = SubmitField('Search')
    
    def __init__(self, *args, **kwargs):
        super(SearchAttendanceForm, self).__init__(*args, **kwargs)
        
        # Add an empty option
        self.department_id.choices = [(0, 'All Departments')]
        self.department_id.choices.extend([(dept.id, dept.name) for dept in Department.query.order_by('name').all()])
        
        self.course_id.choices = [(0, 'All Courses')]
        self.course_id.choices.extend([(course.id, f"{course.code} - {course.title}") 
                                     for course in Course.query.order_by('code').all()])

class UpdateProfileForm(FlaskForm):
    first_name = StringField('First Name', validators=[DataRequired(), Length(min=2, max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(min=2, max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    current_password = PasswordField('Current Password')
    new_password = PasswordField('New Password')
    confirm_password = PasswordField('Confirm New Password', validators=[EqualTo('new_password', message='Passwords must match')])
    submit = SubmitField('Update Profile')
    
    def __init__(self, user, *args, **kwargs):
        super(UpdateProfileForm, self).__init__(*args, **kwargs)
        self.user = user
    
    def validate_email(self, email):
        if email.data != self.user.email:
            user = User.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('Email already registered. Please use a different email.')
    
    def validate_current_password(self, current_password):
        if self.new_password.data and not self.user.check_password(current_password.data):
            raise ValidationError('Incorrect password. Please enter your current password correctly.')
