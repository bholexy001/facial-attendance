// Camera.js - Handles camera access and captures for facial recognition

class Camera {
    constructor(videoElement, canvasElement) {
        this.video = videoElement;
        this.canvas = canvasElement;
        this.context = this.canvas.getContext('2d');
        this.stream = null;
        this.lastError = null;
        this.initializationAttempts = 0;
        this.maxInitializationAttempts = 3;
    }

    /**
     * Initialize the camera with the specified constraints
     */
    async initialize(facingMode = 'user', width = 640, height = 480) {
        try {
            this.initializationAttempts++;
            console.log(`Camera initialization attempt ${this.initializationAttempts}`);
            
            // Check if devices are available
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(device => device.kind === 'videoinput');
            
            if (videoDevices.length === 0) {
                throw new Error('No camera devices found on this device');
            }
            
            console.log(`Found ${videoDevices.length} video devices`);
            
            // Request camera access with specified constraints
            const constraints = {
                video: {
                    width: { ideal: width },
                    height: { ideal: height },
                    facingMode: facingMode
                }
            };
            
            console.log('Requesting media with constraints:', JSON.stringify(constraints));
            this.stream = await navigator.mediaDevices.getUserMedia(constraints);
            
            // Set the video source to the camera stream
            this.video.srcObject = this.stream;
            
            // Wait for video metadata to load to set canvas dimensions
            return new Promise((resolve) => {
                this.video.onloadedmetadata = () => {
                    this.canvas.width = this.video.videoWidth;
                    this.canvas.height = this.video.videoHeight;
                    console.log(`Camera initialized with resolution ${this.canvas.width}x${this.canvas.height}`);
                    this.video.play();
                    this.initializationAttempts = 0; // Reset counter on success
                    this.lastError = null;
                    resolve(true);
                };
                
                // Add timeout in case metadata never loads
                setTimeout(() => {
                    if (!this.video.videoWidth) {
                        console.warn('Video metadata load timeout, using default dimensions');
                        this.canvas.width = width;
                        this.canvas.height = height;
                        resolve(true);
                    }
                }, 3000);
            });
        } catch (error) {
            console.error('Error accessing camera:', error);
            this.lastError = error;
            
            // If we've tried too many times, give up
            if (this.initializationAttempts >= this.maxInitializationAttempts) {
                throw new Error(`Failed to initialize camera after ${this.initializationAttempts} attempts: ${error.message}`);
            }
            
            // If it's a permission error, don't retry automatically
            if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
                throw new Error('Camera access denied. Please grant camera permissions and try again.');
            }
            
            // For other errors, try with different constraints
            if (facingMode === 'user') {
                console.log('Retrying with environment facing mode');
                return this.initialize('environment', width, height);
            } else if (width > 320) {
                console.log('Retrying with lower resolution');
                return this.initialize(facingMode, 320, 240);
            } else {
                // Last resort: try with minimal constraints
                console.log('Retrying with minimal constraints');
                this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
                this.video.srcObject = this.stream;
                
                return new Promise((resolve) => {
                    this.video.onloadedmetadata = () => {
                        this.canvas.width = this.video.videoWidth || 320;
                        this.canvas.height = this.video.videoHeight || 240;
                        this.video.play();
                        resolve(true);
                    };
                    
                    setTimeout(() => {
                        if (!this.video.videoWidth) {
                            this.canvas.width = 320;
                            this.canvas.height = 240;
                            resolve(true);
                        }
                    }, 3000);
                });
            }
        }
    }

    /**
     * Capture a frame from the video stream and return as a Blob
     */
    captureFrame(format = 'image/jpeg', quality = 0.95) {
        if (!this.stream || !this.video.videoWidth) {
            console.error('Cannot capture frame: camera not initialized or video not ready');
            return null;
        }
        
        try {
            // Draw current video frame to canvas
            this.context.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
            
            // Return a promise that resolves with the image blob
            return new Promise((resolve, reject) => {
                try {
                    this.canvas.toBlob((blob) => {
                        if (!blob) {
                            reject(new Error('Failed to create image blob'));
                            return;
                        }
                        resolve(blob);
                    }, format, quality);
                } catch (e) {
                    reject(e);
                }
            });
        } catch (error) {
            console.error('Error capturing frame:', error);
            return null;
        }
    }

    /**
     * Stop the camera stream
     */
    stop() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => {
                try {
                    track.stop();
                } catch (e) {
                    console.warn('Error stopping track:', e);
                }
            });
            this.stream = null;
        }
        
        // Clear video source
        if (this.video.srcObject) {
            this.video.srcObject = null;
        }
    }

    /**
     * Switch between front and back cameras if available
     */
    async switchCamera() {
        // Get current facing mode
        const currentFacingMode = this.getCurrentFacingMode();
        console.log(`Switching camera from ${currentFacingMode} mode`);
        
        // Stop current stream
        this.stop();
        
        // Initialize with opposite facing mode
        const newFacingMode = currentFacingMode === 'user' ? 'environment' : 'user';
        await this.initialize(newFacingMode);
        console.log(`Camera switched to ${this.getCurrentFacingMode()} mode`);
    }

    /**
     * Get the current facing mode of the camera
     */
    getCurrentFacingMode() {
        if (!this.stream) return null;
        
        try {
            const videoTrack = this.stream.getVideoTracks()[0];
            if (!videoTrack) return 'user';
            
            const settings = videoTrack.getSettings();
            return settings.facingMode || 'user';
        } catch (e) {
            console.warn('Error getting facing mode:', e);
            return 'user';
        }
    }
    
    /**
     * Get the current stream
     */
    getCurrentStream() {
        return this.stream;
    }
    
    /**
     * Check if a camera is available
     */
    static async isCameraAvailable() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            return devices.some(device => device.kind === 'videoinput');
        } catch (e) {
            console.error('Error checking camera availability:', e);
            return false;
        }
    }
    
    /**
     * Get available camera devices
     */
    static async getAvailableCameras() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            return devices.filter(device => device.kind === 'videoinput');
        } catch (e) {
            console.error('Error getting available cameras:', e);
            return [];
        }
    }
}

// Export the Camera class
window.Camera = Camera;
