"""
Script to add a General department for courses applicable to all departments
"""
from app import app, db
from models import Department

def add_general_department():
    """Add a General department if it doesn't exist"""
    with app.app_context():
        # Check if General department already exists
        general_dept = Department.query.filter_by(code='GEN').first()
        
        if general_dept:
            print("General department already exists.")
            return general_dept
            
        # Create the General department
        general_dept = Department(
            name="General",
            code="GEN"
        )
        
        db.session.add(general_dept)
        db.session.commit()
        
        print("General department created successfully!")
        return general_dept

if __name__ == "__main__":
    add_general_department()