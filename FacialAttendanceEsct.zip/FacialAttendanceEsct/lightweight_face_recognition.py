"""
Lightweight Face Recognition Module
This is an alternative to the face_recognition library using OpenCV's built-in face detection
It does not do actual facial recognition, but simulates it for demonstration purposes
"""

import cv2
import numpy as np
import pickle
import logging
import os
from PIL import Image
import io

# Ensure the haarcascade file is downloaded if needed
CASCADE_PATH = "haarcascade_frontalface_default.xml"
CASCADE_URL = "https://raw.githubusercontent.com/opencv/opencv/master/data/haarcascades/haarcascade_frontalface_default.xml"

def ensure_cascade_file():
    """Download the cascade file if it doesn't exist"""
    if not os.path.exists(CASCADE_PATH):
        import urllib.request
        logging.info(f"Downloading cascade file from {CASCADE_URL}")
        urllib.request.urlretrieve(CASCADE_URL, CASCADE_PATH)
        logging.info(f"Cascade file downloaded to {CASCADE_PATH}")

# Initialize on import
ensure_cascade_file()

class LightweightFaceRecognition:
    @staticmethod
    def load_image_file(file_path):
        """Load an image file and convert to a format suitable for OpenCV"""
        logging.info(f"Loading image from {file_path}")
        image = cv2.imread(file_path)
        return image

    @staticmethod
    def face_locations(image):
        """Detect faces in an image"""
        logging.info("Detecting face locations")
        if image is None:
            logging.error("Image is None, cannot detect faces")
            return []
            
        # Convert to grayscale for face detection
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) > 2 else image
        
        # Load the face detector
        face_cascade = cv2.CascadeClassifier(CASCADE_PATH)
        
        # Detect faces
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)
        
        # Convert to the format expected by the original face_recognition library
        locations = []
        for (x, y, w, h) in faces:
            locations.append((y, x+w, y+h, x))  # top, right, bottom, left
        
        logging.info(f"Detected {len(locations)} faces")
        return locations

    @staticmethod
    def face_encodings(image, face_locations=None):
        """Generate a face encoding which is a simplified feature vector"""
        logging.info("Generating face encodings")
        if not face_locations:
            face_locations = LightweightFaceRecognition.face_locations(image)
        
        encodings = []
        for (top, right, bottom, left) in face_locations:
            # Extract the face
            face = image[top:bottom, left:right]
            
            # In a real system, we'd extract facial features here
            # For this demo, we'll just create a simple feature vector based on image data
            if face.size == 0:
                logging.error("Face region is empty")
                # Create a random encoding as a fallback
                encoding = np.random.rand(128)
            else:
                # Resize to a standard size
                face = cv2.resize(face, (50, 50))
                # Flatten and normalize
                encoding = face.flatten().astype(np.float64)
                # Reduce to expected size (128)
                encoding = cv2.PCA(n_components=128).fit_transform(encoding.reshape(1, -1))[0]
                # Normalize
                encoding = encoding / np.linalg.norm(encoding)
            
            encodings.append(encoding)
        
        return encodings

    @staticmethod
    def compare_faces(known_face_encodings, face_encoding_to_check, tolerance=0.6):
        """Compare face encodings to see if they match"""
        logging.info("Comparing faces")
        if len(known_face_encodings) == 0:
            return []
            
        # Calculate distances between face encodings
        distance = np.linalg.norm(known_face_encodings - face_encoding_to_check, axis=1)
        
        # Return boolean array of matches
        return list(distance <= tolerance)

    @staticmethod
    def process_image_data(image_data):
        """Process image data from a file upload"""
        try:
            # Convert image data to numpy array
            image = Image.open(io.BytesIO(image_data))
            return np.array(image)
        except Exception as e:
            logging.error(f"Error processing image data: {e}")
            return None