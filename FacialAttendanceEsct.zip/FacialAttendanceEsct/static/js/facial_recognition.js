/**
 * Facial Recognition JS
 * Handles the facial recognition functionality for the attendance system
 */

class FacialRecognition {
    constructor(camera, loadingElement, resultElement) {
        this.camera = camera;
        this.loadingElement = loadingElement;
        this.resultElement = resultElement;
        this.processing = false;
        this.retryCount = 0;
        this.maxRetries = 3;
    }

    /**
     * Capture an image and send it to the server for facial recognition
     */
    async recognizeFace(endpoint) {
        if (this.processing) {
            return { success: false, message: 'Recognition is already in progress' };
        }

        try {
            this.processing = true;
            this.showLoading();

            // Check if camera is initialized
            if (!this.camera.getCurrentStream()) {
                try {
                    await this.camera.initialize();
                    // Add a small delay to allow camera to fully initialize
                    await new Promise(resolve => setTimeout(resolve, 500));
                } catch (cameraError) {
                    throw new Error(`Camera not available: ${cameraError.message}. Please ensure camera permissions are granted.`);
                }
            }

            // Capture image from camera
            const imageBlob = await this.camera.captureFrame();
            if (!imageBlob) {
                throw new Error('Failed to capture image. Please try again.');
            }

            // Create form data for sending to server
            const formData = new FormData();
            formData.append('face_image', imageBlob, `face_${new Date().getTime()}.jpg`);

            // Send to server for recognition with timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
            
            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    body: formData,
                    signal: controller.signal
                });
                
                clearTimeout(timeoutId);
                
                if (!response.ok) {
                    throw new Error(`Server error: ${response.status} ${response.statusText}`);
                }
                
                // Parse response
                const result = await response.json();
                
                // Reset retry count on success
                this.retryCount = 0;
                
                // Show recognition result
                this.showResult(result);
                
                // Update UI for recognized student if successful
                if (result.success) {
                    this.updateStudentStatus(result);
                }

                return result;
            } catch (fetchError) {
                clearTimeout(timeoutId);
                if (fetchError.name === 'AbortError') {
                    throw new Error('Recognition request timed out. Please try again.');
                }
                throw fetchError;
            }
        } catch (error) {
            console.error('Facial recognition error:', error);
            
            // Try to automatically retry up to max retries
            if (this.retryCount < this.maxRetries && 
                (error.message.includes('capture') || error.message.includes('timed out'))) {
                this.retryCount++;
                this.showResult({
                    success: false,
                    message: `Retrying... (${this.retryCount}/${this.maxRetries})`
                });
                
                // Wait a moment before retry
                await new Promise(resolve => setTimeout(resolve, 1000));
                this.processing = false;
                return this.recognizeFace(endpoint);
            }
            
            return { 
                success: false, 
                message: `Error: ${error.message}. Please try again or check your camera.` 
            };
        } finally {
            this.processing = false;
            this.hideLoading();
        }
    }

    /**
     * Show loading indicator
     */
    showLoading() {
        if (this.loadingElement) {
            this.loadingElement.style.display = 'block';
            this.loadingElement.setAttribute('aria-busy', 'true');
        }
    }

    /**
     * Hide loading indicator
     */
    hideLoading() {
        if (this.loadingElement) {
            setTimeout(() => {
                this.loadingElement.style.display = 'none';
                this.loadingElement.setAttribute('aria-busy', 'false');
            }, 500); // Small delay to ensure user sees feedback
        }
    }

    /**
     * Show recognition result
     */
    showResult(result) {
        if (!this.resultElement) return;

        // Set text and style based on result
        if (result.success) {
            if (result.duplicate) {
                this.resultElement.innerHTML = `<i class="fas fa-exclamation-circle me-2"></i>${result.student_name} (${result.student_id}) - ${result.message}`;
                this.resultElement.className = 'recognition-result bg-warning text-dark';
            } else {
                this.resultElement.innerHTML = `<i class="fas fa-check-circle me-2"></i>${result.student_name} (${result.student_id}) - ${result.message}`;
                this.resultElement.className = 'recognition-result bg-success text-white';
            }
        } else {
            this.resultElement.innerHTML = `<i class="fas fa-times-circle me-2"></i>${result.message}`;
            this.resultElement.className = 'recognition-result bg-danger text-white';
        }

        // Ensure proper accessibility
        this.resultElement.setAttribute('role', 'alert');
        this.resultElement.setAttribute('aria-live', 'assertive');

        // Show result
        this.resultElement.style.display = 'block';

        // Hide after a few seconds unless it's an error
        const timeout = result.success ? 3000 : 5000;
        setTimeout(() => {
            this.resultElement.style.display = 'none';
        }, timeout);
    }

    /**
     * Update student status in the UI
     */
    updateStudentStatus(result) {
        // If the recognition was successful and not a duplicate
        if (result.success && !result.duplicate) {
            // Find the student element in the list
            const studentElement = document.getElementById(`student-${result.student_id}`);
            if (studentElement) {
                // Update the attendance status display
                const statusElement = studentElement.querySelector('.attendance-status');
                if (statusElement) {
                    statusElement.innerHTML = '<span class="badge bg-success"><i class="fas fa-check-circle attendance-status-icon"></i> Present</span>';
                }
                
                // Update the counter if it exists
                const counterElement = document.getElementById('present-counter');
                if (counterElement) {
                    const currentCount = parseInt(counterElement.textContent, 10) || 0;
                    counterElement.textContent = currentCount + 1;
                }
                
                // Add a visual highlight effect to show which student was just recognized
                studentElement.classList.add('highlight-student');
                setTimeout(() => {
                    studentElement.classList.remove('highlight-student');
                }, 2000);
                
                // Scroll to the student in the list
                studentElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    }
    
    /**
     * Switch camera (front/back) if available
     */
    async switchCamera() {
        if (this.processing) {
            return false;
        }
        
        try {
            await this.camera.switchCamera();
            return true;
        } catch (error) {
            console.error('Error switching camera:', error);
            this.showResult({
                success: false,
                message: `Could not switch camera: ${error.message}`
            });
            return false;
        }
    }
}

// Export the FacialRecognition class
window.FacialRecognition = FacialRecognition;

// Helper function to initialize facial recognition workflow
function initFacialRecognition(videoSelector, canvasSelector, captureButtonSelector, loadingSelector, resultSelector, apiEndpoint) {
    document.addEventListener('DOMContentLoaded', function() {
        const video = document.querySelector(videoSelector);
        const canvas = document.querySelector(canvasSelector);
        const captureBtn = document.querySelector(captureButtonSelector);
        const loadingSpinner = document.querySelector(loadingSelector);
        const recognitionResult = document.querySelector(resultSelector);
        
        if (!video || !canvas || !captureBtn) {
            console.error('Required elements not found');
            return;
        }
        
        // Initialize camera
        const camera = new Camera(video, canvas);
        camera.initialize()
            .then(() => {
                console.log('Camera initialized successfully');
            })
            .catch(error => {
                console.error('Error initializing camera:', error);
                alert(`Camera error: ${error.message}. Please ensure you have granted camera permissions.`);
            });
        
        // Initialize facial recognition
        const facialRecognition = new FacialRecognition(camera, loadingSpinner, recognitionResult);
        
        // Set up capture button
        captureBtn.addEventListener('click', function() {
            facialRecognition.recognizeFace(apiEndpoint)
                .catch(error => {
                    console.error('Recognition error:', error);
                    alert('An error occurred during face recognition. Please try again.');
                });
        });
        
        // Clean up on page unload
        window.addEventListener('beforeunload', function() {
            camera.stop();
        });
    });
}

// Make helper function globally available
window.initFacialRecognition = initFacialRecognition;
