"""
Script to migrate the database to add the is_general column to the Course model and adjust the unique constraint on the course code
"""
from app import app, db

def migrate_database():
    """
    Drop existing tables, recreate them with the new schema, and add the is_general column if it doesn't exist.
    """
    with app.app_context():
        try:
            # Drop existing tables
            db.drop_all()

            # Create tables with new schema
            db.create_all()

            print("Migration successful!")
        except Exception as e:
            print(f"Error during migration: {e}")
            db.session.rollback()

if __name__ == "__main__":
    migrate_database()