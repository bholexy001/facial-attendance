from flask import render_template, redirect, url_for, flash, request, session, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from models import User, Student, Lecturer, Department, Course, CourseAssignment, AttendanceSession, Attendance, FaceData, MissedClassReport, Role
from forms import (LoginForm, AdminRegistrationForm, LecturerRegistrationForm, StudentRegistrationForm, 
                 DepartmentForm, CourseForm, CourseAssignmentForm, TakeAttendanceForm, ModifyAttendanceForm, 
                 ReportMissedClassForm, SearchAttendanceForm, UpdateProfileForm)
from utils import (admin_required, lecturer_required, student_required, process_face_images, 
                 recognize_face, send_attendance_notification, send_attendance_modification_notification,
                 send_missed_class_report_notification, get_attendance_statistics)
from datetime import datetime

# Context processor to make date/time available to all templates
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Home route
@app.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.is_admin():
            return redirect(url_for('admin_dashboard'))
        elif current_user.is_lecturer():
            return redirect(url_for('lecturer_dashboard'))
        elif current_user.is_student():
            return redirect(url_for('student_dashboard'))
    return render_template('index.html')

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Login failed. Please check your email and password.', 'danger')

    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# Admin routes
@app.route('/admin/dashboard')
@login_required
@admin_required
def admin_dashboard():
    # Get counts for dashboard
    student_count = Student.query.count()
    lecturer_count = Lecturer.query.count()
    department_count = Department.query.count()
    course_count = Course.query.count()
    report_count = MissedClassReport.query.filter_by(status='pending').count()

    # Get recent reports
    recent_reports = MissedClassReport.query.order_by(MissedClassReport.created_at.desc()).limit(5).all()
    report_data = []

    for report in recent_reports:
        student = Student.query.get(report.student_id)
        course = Course.query.get(report.course_id)
        user = None

        if student:
            user = User.query.get(student.user_id)

        if user and course:
            report_data.append({
                'id': report.id,
                'student_name': f"{user.first_name} {user.last_name}",
                'course_code': course.code,
                'date': report.date,
                'status': report.status
            })

    return render_template('admin/dashboard.html', 
                          student_count=student_count,
                          lecturer_count=lecturer_count,
                          department_count=department_count,
                          course_count=course_count,
                          report_count=report_count,
                          reports=report_data)

@app.route('/admin/register/admin', methods=['GET', 'POST'])
@login_required
@admin_required
def register_admin():
    form = AdminRegistrationForm()

    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            role=Role.ADMIN
        )
        user.set_password(form.password.data)

        db.session.add(user)
        db.session.commit()

        flash('Administrator registered successfully!', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('admin/register_user.html', form=form, user_type='admin')

@app.route('/admin/register/lecturer', methods=['GET', 'POST'])
@login_required
@admin_required
def register_lecturer():
    form = LecturerRegistrationForm()

    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            role=Role.LECTURER
        )
        user.set_password(form.password.data)

        db.session.add(user)
        db.session.flush()  # Flush to get the user ID

        lecturer = Lecturer(
            user_id=user.id,
            staff_id=form.staff_id.data
        )

        db.session.add(lecturer)
        db.session.commit()

        flash('Lecturer registered successfully!', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('admin/register_user.html', form=form, user_type='lecturer')

@app.route('/admin/register/student', methods=['GET', 'POST'])
@login_required
@admin_required
def register_student():
    form = StudentRegistrationForm()

    if form.validate_on_submit():
        try:
            # Process the face images
            face_encodings = process_face_images(
                form.face_photo_1.data,
                form.face_photo_2.data,
                form.face_photo_3.data
            )

            user = User(
                username=form.username.data,
                email=form.email.data,
                first_name=form.first_name.data,
                last_name=form.last_name.data,
                role=Role.STUDENT
            )
            user.set_password(form.password.data)

            db.session.add(user)
            db.session.flush()  # Flush to get the user ID

            student = Student(
                user_id=user.id,
                student_id=form.student_id.data,
                department_id=form.department_id.data,
                level=form.level.data
            )

            db.session.add(student)
            db.session.flush()  # Flush to get the student ID

            face_data = FaceData(
                student_id=student.id,
                face_encoding_1=face_encodings[0],
                face_encoding_2=face_encodings[1],
                face_encoding_3=face_encodings[2]
            )

            db.session.add(face_data)
            db.session.commit()

            flash('Student registered successfully!', 'success')
            return redirect(url_for('admin_dashboard'))

        except Exception as e:
            db.session.rollback()
            flash(f'Error registering student: {str(e)}', 'danger')

    return render_template('admin/register_user.html', form=form, user_type='student')

@app.route('/admin/departments', methods=['GET', 'POST'])
@login_required
@admin_required
def manage_departments():
    form = DepartmentForm()

    if form.validate_on_submit():
        department = Department(
            name=form.name.data,
            code=form.code.data
        )

        db.session.add(department)
        db.session.commit()

        flash('Department added successfully!', 'success')
        return redirect(url_for('manage_departments'))

    departments = Department.query.all()
    return render_template('admin/register_course.html', form=form, departments=departments, section='department')

@app.route('/admin/delete-course/<int:course_id>', methods=['POST'])
@login_required
@admin_required
def delete_course(course_id):
    course = Course.query.get_or_404(course_id)

    # Check if course is assigned to any lecturers
    assignments = CourseAssignment.query.filter_by(course_id=course_id).first()
    if assignments:
        flash(f'Cannot delete "{course.code} - {course.title}" because it is assigned to lecturers.', 'warning')
        return redirect(url_for('manage_courses'))

    # Check if course has attendance sessions
    sessions = AttendanceSession.query.filter_by(course_id=course_id).first()
    if sessions:
        flash(f'Cannot delete "{course.code} - {course.title}" because it has attendance records.', 'warning')
        return redirect(url_for('manage_courses'))

    try:
        # Store name for flash message before deletion
        course_name = f"{course.code} - {course.title}"

        # Delete the course
        db.session.delete(course)
        db.session.commit()

        flash(f'Course "{course_name}" has been deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting course: {str(e)}', 'danger')

    return redirect(url_for('manage_courses'))

@app.route('/admin/clear-courses', methods=['POST'])
@login_required
@admin_required
def clear_courses():
    try:
        # Delete all courses that don't have attendance records or assignments
        courses = Course.query.all()
        deleted_count = 0

        for course in courses:
            if not course.assignments and not course.attendance_sessions:
                db.session.delete(course)
                deleted_count += 1

        db.session.commit()
        flash(f'Successfully deleted {deleted_count} courses.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting courses: {str(e)}', 'danger')

    return redirect(url_for('manage_courses'))

@app.route('/admin/courses', methods=['GET', 'POST'])
@login_required
@admin_required
def manage_courses():
    form = CourseForm()
    course_id = request.args.get('edit', type=int)

    # Check if we're editing an existing course
    if course_id:
        course = Course.query.get_or_404(course_id)
        if request.method == 'GET':
            form.code.data = course.code
            form.title.data = course.title
            form.department_id.data = course.department_id
            form.level.data = course.level
            form.semester.data = course.semester
            form.is_general.data = course.is_general
            form.submit.label.text = 'Update Course'
    else:
        course = None

    if form.validate_on_submit():
        if course:
            # Update existing course
            old_is_general = course.is_general

            # Basic update for the existing course
            course.code = form.code.data
            course.title = form.title.data
            course.department_id = form.department_id.data
            course.level = form.level.data
            course.semester = form.semester.data
            course.is_general = True  # Mark the original course as general too

            db.session.commit()

            # If transitioning from non-general to general, create copies for all departments
            if form.is_general.data and not old_is_general:
                departments = Department.query.all()
                original_dept_id = form.department_id.data
                added_courses = []

                for dept in departments:
                    # Skip the original department as the course already exists
                    if dept.id == original_dept_id:
                        continue

                    # Use original course code for all departments
                    course_code = form.code.data

                    # Check if course code already exists
                    existing = Course.query.filter_by(code=course_code, department_id=dept.id).first()
                    if existing:
                        continue  # Skip if course code already exists

                    # Create the course
                    new_course = Course(
                        code=course_code,
                        title=form.title.data,
                        department_id=dept.id,
                        level=form.level.data,
                        semester=form.semester.data,
                        is_general=True  # Mark all copies as general courses
                    )
                    db.session.add(new_course)
                    added_courses.append(new_course)

                db.session.commit()

                if added_courses:
                    flash(f'Course updated and added to {len(added_courses)} additional departments!', 'success')
                else:
                    flash('Course updated, but no additional courses were added. Course codes may already exist.', 'warning')
            else:
                flash('Course updated successfully!', 'success')
        else:
            # Create new course
            if form.is_general.data:
                # For general courses, create copies for all departments with same course code
                departments = Department.query.all()
                added_courses = []
                course_code = form.code.data  # Use the same course code for all departments

                # First check if course code exists in any department
                existing_courses = Course.query.filter_by(code=course_code).all()
                if existing_courses:
                    # Only proceed if no non-general courses exist with this code
                    non_general_exists = any(not course.is_general for course in existing_courses)
                    if non_general_exists:
                        flash('Course code already exists as a non-general course. Please use a different code.', 'warning')
                        return redirect(url_for('manage_courses'))
                    else:
                        # Delete existing general courses with this code
                        for existing in existing_courses:
                            db.session.delete(existing)
                        db.session.commit()

                for dept in departments:
                    # Create the course
                    course = Course(
                        code=course_code,
                        title=form.title.data,
                        department_id=dept.id,
                        level=form.level.data,
                        semester=form.semester.data,
                        is_general=True  # Mark all copies as general courses
                    )
                    db.session.add(course)
                    added_courses.append(course)

                db.session.commit()

                if added_courses:
                    flash(f'Course added successfully to {len(added_courses)} departments!', 'success')
                else:
                    flash('No courses were added. Course codes may already exist.', 'warning')
            else:
                # Create a single department-specific course
                course = Course(
                    code=form.code.data,
                    title=form.title.data,
                    department_id=form.department_id.data,
                    level=form.level.data,
                    semester=form.semester.data,
                    is_general=False
                )

                db.session.add(course)
                db.session.commit()
                flash('Course added successfully!', 'success')
        return redirect(url_for('manage_courses'))

    courses = db.session.query(
        Course, Department
    ).join(
        Department, Course.department_id == Department.id
    ).all()

    return render_template('admin/register_course.html', form=form, courses=courses, section='course', edit_mode=course_id is not None)

@app.route('/admin/assign-course', methods=['GET', 'POST'])
@login_required
@admin_required
def assign_course():
    form = CourseAssignmentForm()

    if form.validate_on_submit():
        # Check if assignment already exists
        existing = CourseAssignment.query.filter_by(
            course_id=form.course_id.data,
            lecturer_id=form.lecturer_id.data,
            academic_year=form.academic_year.data
        ).first()

        if existing:
            flash('This course is already assigned to this lecturer for the specified academic year.', 'warning')
        else:
            assignment = CourseAssignment(
                course_id=form.course_id.data,
                lecturer_id=form.lecturer_id.data,
                academic_year=form.academic_year.data
            )

            db.session.add(assignment)
            db.session.commit()

            flash('Course assigned successfully!', 'success')

        return redirect(url_for('assign_course'))

    # Get all course assignments with course and lecturer information
    assignments = db.session.query(
        CourseAssignment, Course, User
    ).join(
        Course, CourseAssignment.course_id == Course.id
    ).join(
        Lecturer, CourseAssignment.lecturer_id == Lecturer.id
    ).join(
        User, Lecturer.user_id == User.id
    ).all()

    return render_template('admin/assign_course.html', form=form, assignments=assignments)

@app.route('/admin/view-attendance', methods=['GET', 'POST'])
@login_required
@admin_required
def view_attendance():
    form = SearchAttendanceForm()
    attendance_data = []

    if form.validate_on_submit() or request.args.get('search'):
        # Get search parameters
        student_name = form.student_name.data if form.validate_on_submit() else request.args.get('student_name')
        department_id = form.department_id.data if form.validate_on_submit() else request.args.get('department_id', type=int)
        level = form.level.data if form.validate_on_submit() else request.args.get('level', type=int)
        course_id = form.course_id.data if form.validate_on_submit() else request.args.get('course_id', type=int)
        date_from = form.date_from.data if form.validate_on_submit() else request.args.get('date_from')
        date_to = form.date_to.data if form.validate_on_submit() else request.args.get('date_to')

        # Build query
        query = db.session.query(
            Attendance, AttendanceSession, Course, Student, User
        ).join(
            AttendanceSession, Attendance.session_id == AttendanceSession.id
        ).join(
            Course, AttendanceSession.course_id == Course.id
        ).join(
            Student, Attendance.student_id == Student.id
        ).join(
            User, Student.user_id == User.id
        )

        # Apply filters
        if student_name:
            query = query.filter(
                (User.first_name.ilike(f'%{student_name}%')) | 
                (User.last_name.ilike(f'%{student_name}%'))
            )

        if department_id and department_id > 0:
            query = query.filter(Student.department_id == department_id)

        if level and level > 0:
            query = query.filter(Student.level == level)

        if course_id and course_id > 0:
            query = query.filter(Course.id == course_id)

        if date_from:
            if isinstance(date_from, str):
                date_from = datetime.strptime(date_from, '%Y-%m-%d').date()
            query = query.filter(AttendanceSession.date >= date_from)

        if date_to:
            if isinstance(date_to, str):
                date_to = datetime.strptime(date_to, '%Y-%m-%d').date()
            query = query.filter(AttendanceSession.date <= date_to)

        # Execute query
        results = query.order_by(AttendanceSession.date.desc()).all()

        # Format results
        for attendance, session, course, student, user in results:
            department = Department.query.get(student.department_id)
            attendance_data.append({
                'id': attendance.id,
                'date': session.date,
                'time': f"{session.start_time} - {session.end_time}",
                'course': f"{course.code} - {course.title}",
                'student': f"{user.first_name} {user.last_name}",
                'student_id': student.student_id,
                'department': department.name if department else "Unknown",
                'level': student.level,
                'status': "Present" if attendance.status else "Absent",
                'modified': attendance.modified
            })

    return render_template('admin/view_attendance.html', form=form, attendance_data=attendance_data)

@app.route('/admin/student-reports')
@login_required
@admin_required
def student_reports():
    reports = db.session.query(
        MissedClassReport, Student, User, Course
    ).join(
        Student, MissedClassReport.student_id == Student.id
    ).join(
        User, Student.user_id == User.id
    ).join(
        Course, MissedClassReport.course_id == Course.id
    ).order_by(MissedClassReport.created_at.desc()).all()

    report_data = []
    for report, student, user, course in reports:
        report_data.append({
            'id': report.id,
            'student_name': f"{user.first_name} {user.last_name}",
            'student_id': student.student_id,
            'course': f"{course.code} - {course.title}",
            'date': report.date,
            'reason': report.reason,
            'status': report.status,
            'created_at': report.created_at
        })

    return render_template('admin/student_reports.html', reports=report_data)

@app.route('/admin/update-report-status/<int:report_id>/<status>')
@login_required
@admin_required
def update_report_status(report_id, status):
    if status not in ['approved', 'rejected']:
        flash('Invalid status.', 'danger')
        return redirect(url_for('student_reports'))

    report = MissedClassReport.query.get_or_404(report_id)
    report.status = status
    db.session.commit()

    flash('Report status updated successfully.', 'success')
    return redirect(url_for('student_reports'))

@app.route('/admin/profile', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_profile():
    form = UpdateProfileForm(current_user)

    if request.method == 'GET':
        form.first_name.data = current_user.first_name
        form.last_name.data = current_user.last_name
        form.email.data = current_user.email

    if form.validate_on_submit():
        current_user.first_name = form.first_name.data
        current_user.last_name = form.last_name.data
        current_user.email = form.email.data

        if form.new_password.data:
            current_user.set_password(form.new_password.data)

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('admin_profile'))

    return render_template('admin/profile.html', form=form)

# Lecturer routes
@app.route('/lecturer/dashboard')
@login_required
@lecturer_required
def lecturer_dashboard():
    # Get lecturer information
    lecturer = Lecturer.query.filter_by(user_id=current_user.id).first()

    if not lecturer:
        flash('Lecturer profile not found.', 'danger')
        return redirect(url_for('index'))

    # Get assigned courses
    assigned_courses = db.session.query(
        CourseAssignment, Course, Department
    ).join(
        Course, CourseAssignment.course_id == Course.id
    ).join(
        Department, Course.department_id == Department.id
    ).filter(
        CourseAssignment.lecturer_id == lecturer.id
    ).all()

    # Get recent attendance sessions
    recent_sessions = db.session.query(
        AttendanceSession, Course
    ).join(
        Course, AttendanceSession.course_id == Course.id
    ).join(
        CourseAssignment, AttendanceSession.assignment_id == CourseAssignment.id
    ).filter(
        CourseAssignment.lecturer_id == lecturer.id
    ).order_by(
        AttendanceSession.date.desc()
    ).limit(5).all()

    session_data = []
    for session, course in recent_sessions:
        present_count = Attendance.query.filter_by(session_id=session.id, status=True).count()
        absent_count = Attendance.query.filter_by(session_id=session.id, status=False).count()
        total = present_count + absent_count

        session_data.append({
            'id': session.id,
            'course': f"{course.code} - {course.title}",
            'date': session.date,
            'time': f"{session.start_time} - {session.end_time}",
            'present': present_count,
            'absent': absent_count,
            'total': total
        })

    course_count = len(assigned_courses)
    session_count = AttendanceSession.query.join(
        CourseAssignment, AttendanceSession.assignment_id == CourseAssignment.id
    ).filter(
        CourseAssignment.lecturer_id == lecturer.id
    ).count()

    return render_template('lecturer/dashboard.html', 
                          assigned_courses=assigned_courses,
                          session_data=session_data,
                          course_count=course_count,
                          session_count=session_count)

@app.route('/lecturer/take-attendance', methods=['GET', 'POST'])
@login_required
@lecturer_required
def take_attendance():
    # Get lecturer information
    lecturer = Lecturer.query.filter_by(user_id=current_user.id).first()

    if not lecturer:
        flash('Lecturer profile not found.', 'danger')
        return redirect(url_for('index'))

    form = TakeAttendanceForm(lecturer.id)

    if form.validate_on_submit():
        # Create attendance session
        assignment = CourseAssignment.query.get_or_404(form.course_assignment_id.data)

        session = AttendanceSession(
            course_id=assignment.course_id,
            assignment_id=assignment.id,
            date=form.date.data,
            start_time=form.start_time.data,
            end_time=form.end_time.data
        )

        db.session.add(session)
        db.session.commit()

        # Store session ID in session for the facial recognition process
        session['current_attendance_session'] = session.id

        flash('Attendance session created. You can now start taking attendance.', 'success')
        return redirect(url_for('record_attendance', session_id=session.id))

    return render_template('lecturer/take_attendance.html', form=form)

@app.route('/lecturer/record-attendance/<int:session_id>', methods=['GET', 'POST'])
@login_required
@lecturer_required
def record_attendance(session_id):
    # Get the attendance session
    attendance_session = AttendanceSession.query.get_or_404(session_id)
    course = Course.query.get_or_404(attendance_session.course_id)

    # Get students based on course type (general or department-specific)
    query = db.session.query(
        Student, User
    ).join(
        User, Student.user_id == User.id
    )

    if course.is_general:
        # For general courses, get students from all departments at this level
        students = query.filter(
            Student.level == course.level
        ).order_by(
            User.last_name,
            User.first_name
        ).all()
    else:
        # For department-specific courses
        students = query.filter(
            Student.department_id == course.department_id,
            Student.level == course.level
        ).order_by(
            User.last_name,
            User.first_name
        ).all()

    # Get face data for all students
    face_data = db.session.query(
        FaceData
    ).filter(
        FaceData.student_id.in_([student.id for student, _ in students])
    ).all()

    # Get existing attendance records
    existing_records = {record.student_id: record for record in Attendance.query.filter_by(session_id=session_id).all()}

    # Prepare student list with attendance status
    student_list = []
    for student, user in students:
        record = existing_records.get(student.id)
        student_list.append({
            'id': student.id,
            'name': f"{user.first_name} {user.last_name}",
            'student_id': student.student_id,
            'status': record.status if record else None,
            'recorded': record is not None
        })

    return render_template('lecturer/take_attendance.html', 
                          course=course,
                          session=attendance_session,
                          students=student_list,
                          recording=True)

@app.route('/api/recognize-face', methods=['POST'])
@login_required
@lecturer_required
def api_recognize_face():
    if 'current_attendance_session' not in session:
        return jsonify({'success': False, 'message': 'No active attendance session'})

    if 'face_image' not in request.files:
        return jsonify({'success': False, 'message': 'No image file provided'})

    face_image = request.files['face_image']
    session_id = session['current_attendance_session']

    # Get attendance session
    attendance_session = AttendanceSession.query.get(session_id)
    if not attendance_session:
        return jsonify({'success': False, 'message': 'Attendance session not found'})

    # Get course
    course = Course.query.get(attendance_session.course_id)
    if not course:
        return jsonify({'success': False, 'message': 'Course not found'})

    # Get face data for all students in this course's department and level
    students = Student.query.filter_by(department_id=course.department_id, level=course.level).all()
    student_ids = [student.id for student in students]

    face_data = FaceData.query.filter(FaceData.student_id.in_(student_ids)).all()

    # Perform facial recognition
    success, student_id, message = recognize_face(face_image, face_data)

    if not success:
        return jsonify({'success': False, 'message': message})

    # Mark attendance
    student = Student.query.get(student_id)
    user = User.query.get(student.user_id)

    # Check if attendance already recorded
    existing = Attendance.query.filter_by(session_id=session_id, student_id=student_id).first()
    if existing:
        return jsonify({
            'success': True,
            'duplicate': True,
            'student_name': f"{user.first_name} {user.last_name}",
            'student_id': student.student_id,
            'message': 'Attendance already recorded for this student'
        })

    # Record attendance
    attendance = Attendance(
        session_id=session_id,
        student_id=student_id,
        status=True  # Present
    )

    db.session.add(attendance)
    db.session.commit()

    return jsonify({
        'success': True,
        'student_name': f"{user.first_name} {user.last_name}",
        'student_id': student.student_id,
        'message': 'Attendance recorded successfully'
    })

@app.route('/lecturer/complete-attendance/<int:session_id>', methods=['POST'])
@login_required
@lecturer_required
def complete_attendance(session_id):
    # Mark all remaining students as absent
    attendance_session = AttendanceSession.query.get_or_404(session_id)
    course = Course.query.get_or_404(attendance_session.course_id)

    # Get all applicable students based on course type
    if course.is_general:
        # For general courses, get students from all departments at this level
        students = Student.query.filter_by(level=course.level).all()
    else:
        # For department-specific courses
        students = Student.query.filter_by(department_id=course.department_id, level=course.level).all()

    # Get existing attendance records
    existing_records = {record.student_id for record in Attendance.query.filter_by(session_id=session_id).all()}

    # Mark absent for students who haven't been recorded
    absent_records = []
    for student in students:
        if student.id not in existing_records:
            absent_records.append(Attendance(
                session_id=session_id,
                student_id=student.id,
                status=False  # Absent
            ))

    if absent_records:
        db.session.bulk_save_objects(absent_records)
        db.session.commit()

    #    # Send email notifications
    success, message = send_attendance_notification(session_id)
    if not success:
        flash(f'Error sending notifications: {message}', 'warning')
    else:
        flash('Attendance completed successfully. Notifications have been sent to students.', 'success')

    # Clear session data
    if 'current_attendance_session' in session:
        session.pop('current_attendance_session')

    return redirect(url_for('lecturer_dashboard'))

@app.route('/lecturer/view-courses')
@login_required
@lecturer_required
def view_courses():
    # Get lecturer information
    lecturer = Lecturer.query.filter_by(user_id=current_user.id).first()

    if not lecturer:
        flash('Lecturer profile not found.', 'danger')
        return redirect(url_for('index'))

    # Get assigned courses
    assigned_courses = db.session.query(
        CourseAssignment, Course, Department
    ).join(
        Course, CourseAssignment.course_id == Course.id
    ).join(
        Department, Course.department_id == Department.id
    ).filter(
        CourseAssignment.lecturer_id == lecturer.id
    ).order_by(
        Course.code
    ).all()

    course_data = []
    for assignment, course, department in assigned_courses:
        # Get attendance sessions for this course
        sessions = AttendanceSession.query.filter_by(assignment_id=assignment.id).order_by(AttendanceSession.date.desc()).all()

        session_data = []
        for session in sessions:
            present_count = Attendance.query.filter_by(session_id=session.id, status=True).count()
            absent_count = Attendance.query.filter_by(session_id=session.id, status=False).count()
            total = present_count + absent_count

            session_data.append({
                'id': session.id,
                'date': session.date,
                'time': f"{session.start_time} - {session.end_time}",
                'present': present_count,
                'absent': absent_count,
                'total': total
            })

        course_data.append({
            'assignment_id': assignment.id,
            'course_id': course.id,
            'code': course.code,
            'title': course.title,
            'department': department.name,
            'level': course.level,
            'semester': course.semester,
            'academic_year': assignment.academic_year,
            'sessions': session_data
        })

    return render_template('lecturer/view_courses.html', courses=course_data)

@app.route('/lecturer/session-details/<int:session_id>')
@login_required
@lecturer_required
def session_details(session_id):
    # Get session details
    session_data = db.session.query(
        AttendanceSession, Course
    ).join(
        Course, AttendanceSession.course_id == Course.id
    ).filter(
        AttendanceSession.id == session_id
    ).first_or_404()

    attendance_session, course = session_data

    # Get attendance records
    attendance_records = db.session.query(
        Attendance, Student, User
    ).join(
        Student, Attendance.student_id == Student.id
    ).join(
        User, Student.user_id == User.id
    ).filter(
        Attendance.session_id == session_id
    ).order_by(
        User.last_name,
        User.first_name
    ).all()

    attendance_data = []
    for attendance, student, user in attendance_records:
        attendance_data.append({
            'id': attendance.id,
            'student_id': student.student_id,
            'student_name': f"{user.first_name} {user.last_name}",
            'status': "Present" if attendance.status else "Absent",
            'modified': attendance.modified,
            'modification_reason': attendance.modification_reason
        })

    # Statistics
    present_count = sum(1 for att, _, _ in attendance_records if att.status)
    absent_count = sum(1 for att, _, _ in attendance_records if not att.status)
    total = len(attendance_records)
    present_percentage = (present_count / total * 100) if total > 0 else 0
    absent_percentage = (absent_count / total * 100) if total > 0 else 0

    stats = {
        'present_count': present_count,
        'absent_count': absent_count,
        'total': total,
        'present_percentage': present_percentage,
        'absent_percentage': absent_percentage
    }

    return render_template('lecturer/modify_attendance.html', 
                          session=attendance_session,
                          course=course,
                          attendance=attendance_data,
                          stats=stats)

@app.route('/lecturer/modify-attendance/<int:attendance_id>', methods=['GET', 'POST'])
@login_required
@lecturer_required
def modify_attendance(attendance_id):
    attendance = Attendance.query.get_or_404(attendance_id)
    session_data = AttendanceSession.query.get_or_404(attendance.session_id)

    # Verify that this lecturer has access to this course
    lecturer = Lecturer.query.filter_by(user_id=current_user.id).first()
    assignment = CourseAssignment.query.get(session_data.assignment_id)

    if not lecturer or not assignment or assignment.lecturer_id != lecturer.id:
        flash('You do not have permission to modify this attendance record.', 'danger')
        return redirect(url_for('lecturer_dashboard'))

    student = Student.query.get(attendance.student_id)
    user = User.query.get(student.user_id)

    form = ModifyAttendanceForm()

    if request.method == 'GET':
        form.status.data = attendance.status

    if form.validate_on_submit():
        # Update attendance
        attendance.status = form.status.data
        attendance.modified = True
        attendance.modified_by = current_user.id
        attendance.modification_reason = form.reason.data

        db.session.commit()

        # Send notification
        send_attendance_modification_notification(attendance.id, current_user.get_full_name())

        flash('Attendance record modified successfully.', 'success')
        return redirect(url_for('session_details', session_id=attendance.session_id))

    return render_template('lecturer/modify_attendance_form.html', 
                          form=form,
                          attendance=attendance,
                          student_name=f"{user.first_name} {user.last_name}",
                          student_id=student.student_id)

@app.route('/lecturer/profile', methods=['GET', 'POST'])
@login_required
@lecturer_required
def lecturer_profile():
    form = UpdateProfileForm(current_user)

    if request.method == 'GET':
        form.first_name.data = current_user.first_name
        form.last_name.data = current_user.last_name
        form.email.data = current_user.email

    if form.validate_on_submit():
        current_user.first_name = form.first_name.data
        current_user.last_name = form.last_name.data
        current_user.email = form.email.data

        if form.new_password.data:
            current_user.set_password(form.new_password.data)

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('lecturer_profile'))

    # Get lecturer details
    lecturer = Lecturer.query.filter_by(user_id=current_user.id).first()

    return render_template('lecturer/profile.html', form=form, lecturer=lecturer)

# Student routes
@app.route('/student/dashboard')
@login_required
@student_required
def student_dashboard():
    # Get student information
    student = Student.query.filter_by(user_id=current_user.id).first()

    if not student:
        flash('Student profile not found.', 'danger')
        return redirect(url_for('index'))

    # Get department
    department = Department.query.get(student.department_id)

    # Get courses for this student's department and level
    # Include general courses available to all departments
    department_courses = Course.query.filter_by(
        department_id=student.department_id, 
        level=student.level
    ).all()

    general_courses = Course.query.filter_by(
        is_general=True,
        level=student.level
    ).all()

    # Combine both sets of courses
    courses = department_courses + [course for course in general_courses if course not in department_courses]

    # Get attendance statistics for each course
    course_stats = []
    for course in courses:
        stats = get_attendance_statistics(student_id=student.id, course_id=course.id)
        course_stats.append({
            'course': course,
            'stats': stats
        })

    # Calculate overall attendance
    overall_stats = get_attendance_statistics(student_id=student.id)

    # Get recent attendance records
    recent_attendance = db.session.query(
        Attendance, AttendanceSession, Course
    ).join(
        AttendanceSession, Attendance.session_id == AttendanceSession.id
    ).join(
        Course, AttendanceSession.course_id == Course.id
    ).filter(
        Attendance.student_id == student.id
    ).order_by(
        AttendanceSession.date.desc()
    ).limit(5).all()

    attendance_data = []
    for attendance, session, course in recent_attendance:
        attendance_data.append({
            'date': session.date,
            'course': f"{course.code} - {course.title}",
            'status': "Present" if attendance.status else "Absent",
            'modified': attendance.modified
        })

    return render_template('student/dashboard.html', 
                          student=student,
                          department=department,
                          course_stats=course_stats,
                          overall_stats=overall_stats,
                          attendance=attendance_data)

@app.route('/student/view-attendance')
@login_required
@student_required
def view_student_attendance():
    # Get student information
    student = Student.query.filter_by(user_id=current_user.id).first()

    if not student:
        flash('Student profile not found.', 'danger')
        return redirect(url_for('index'))

    # Get courses for this student's department and level
    # Include general courses available to all departments
    department_courses = Course.query.filter_by(
        department_id=student.department_id, 
        level=student.level
    ).all()

    general_courses = Course.query.filter_by(
        is_general=True,
        level=student.level
    ).all()

    # Combine both sets of courses
    courses = department_courses + [course for course in general_courses if course not in department_courses]

    # Filter by course if provided
    course_id = request.args.get('course_id', type=int)
    course_filter = Course.id == course_id if course_id else True

    # Get attendance records
    attendance_records = db.session.query(
        Attendance, AttendanceSession, Course
    ).join(
        AttendanceSession, Attendance.session_id == AttendanceSession.id
    ).join(
        Course, AttendanceSession.course_id == Course.id
    ).filter(
        Attendance.student_id == student.id,
        course_filter
    ).order_by(
        AttendanceSession.date.desc()
    ).all()

    attendance_data = []
    for attendance, session, course in attendance_records:
        attendance_data.append({
            'id': attendance.id,
            'date': session.date,
            'time': f"{session.start_time} - {session.end_time}",
            'course': f"{course.code} - {course.title}",
            'status': "Present" if attendance.status else "Absent",
            'modified': attendance.modified,
            'modification_reason': attendance.modification_reason if attendance.modified else None
        })

    # Calculate statistics
    stats = get_attendance_statistics(student_id=student.id, course_id=course_id)

    return render_template('student/view_attendance.html', 
                          student=student,
                          courses=courses,
                          attendance=attendance_data,
                          stats=stats,
                          selected_course_id=course_id)

@app.route('/student/report-missed-class', methods=['GET', 'POST'])
@login_required
@student_required
def report_missed_class():
    # Get student information
    student = Student.query.filter_by(user_id=current_user.id).first()

    if not student:
        flash('Student profile not found.', 'danger')
        return redirect(url_for('index'))

    form = ReportMissedClassForm(student)

    if form.validate_on_submit():
        report = MissedClassReport(
            student_id=student.id,
            course_id=form.course_id.data,
            date=form.date.data,
            reason=form.reason.data
        )

        db.session.add(report)
        db.session.commit()

        # Send notification to admin
        send_missed_class_report_notification(report.id)

        flash('Your report has been submitted successfully.', 'success')
        return redirect(url_for('view_reports'))

    return render_template('student/report_missed_class.html', form=form)

@app.route('/student/reports')
@login_required
@student_required
def view_reports():
    # Get student information
    student = Student.query.filter_by(user_id=current_user.id).first()

    if not student:
        flash('Student profile not found.', 'danger')
        return redirect(url_for('index'))

    # Get reports
    reports = db.session.query(
        MissedClassReport, Course
    ).join(
        Course, MissedClassReport.course_id == Course.id
    ).filter(
        MissedClassReport.student_id == student.id
    ).order_by(
        MissedClassReport.created_at.desc()
    ).all()

    report_data = []
    for report, course in reports:
        report_data.append({
            'id': report.id,
            'course': f"{course.code} - {course.title}",
            'date': report.date,
            'reason': report.reason,
            'status': report.status,
            'created_at': report.created_at
        })

    return render_template('student/view_reports.html', reports=report_data)

@app.route('/student/profile', methods=['GET', 'POST'])
@login_required
@student_required
def student_profile():
    form = UpdateProfileForm(current_user)

    if request.method == 'GET':
        form.first_name.data = current_user.first_name
        form.last_name.data = current_user.last_name
        form.email.data = current_user.email

    if form.validate_on_submit():
        current_user.first_name = form.first_name.data
        current_user.last_name = form.last_name.data
        current_user.email = form.email.data

        if form.new_password.data:
            current_user.set_password(form.new_password.data)

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('student_profile'))

    # Get student details
    student = Student.query.filter_by(user_id=current_user.id).first()
    department = Department.query.get(student.department_id) if student else None

    return render_template('student/profile.html', 
                          form=form, 
                          student=student, 
                          department=department)