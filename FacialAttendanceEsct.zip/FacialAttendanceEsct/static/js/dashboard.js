/**
 * Dashboard JS
 * Handles dashboard functionality for the attendance system
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    initTooltips();
    
    // Initialize charts if they exist
    initCharts();
    
    // Handle tab selection retention
    handleTabSelection();
    
    // Add animation for stat cards
    animateStatCards();
    
    // Initialize datepickers
    initDatepickers();
    
    // Enable course filter dropdown behavior
    enableCourseFilters();
});

/**
 * Initialize Bootstrap tooltips
 */
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Initialize all charts on the dashboard
 */
function initCharts() {
    // Overall attendance chart (doughnut)
    initOverallAttendanceChart();
    
    // Course attendance chart (bar)
    initCourseAttendanceChart();
    
    // Attendance trends chart (line) if it exists
    initAttendanceTrendsChart();
}

/**
 * Initialize overall attendance doughnut chart
 */
function initOverallAttendanceChart() {
    const chartElement = document.getElementById('overallAttendanceChart');
    if (!chartElement) return;
    
    // Get data from the page or use sample data
    const presentCount = chartElement.getAttribute('data-present') || 0;
    const absentCount = chartElement.getAttribute('data-absent') || 0;
    
    const ctx = chartElement.getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Present', 'Absent'],
            datasets: [{
                data: [presentCount, absentCount],
                backgroundColor: [
                    'rgba(40, 167, 69, 0.7)',
                    'rgba(220, 53, 69, 0.7)'
                ],
                borderColor: [
                    'rgba(40, 167, 69, 1)',
                    'rgba(220, 53, 69, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = parseInt(presentCount) + parseInt(absentCount);
                            const value = context.raw;
                            const percentage = Math.round((value / total) * 100);
                            return `${context.label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                animateScale: true
            }
        }
    });
}

/**
 * Initialize course attendance bar chart
 */
function initCourseAttendanceChart() {
    const chartElement = document.getElementById('coursesAttendanceChart');
    if (!chartElement) return;
    
    // Data would be provided by the template rendering
    // This is just a placeholder for the chart initialization
    // The actual data is rendered via Jinja2 template
}

/**
 * Initialize attendance trends line chart
 */
function initAttendanceTrendsChart() {
    const chartElement = document.getElementById('attendanceTrendsChart');
    if (!chartElement) return;
    
    // Data would be provided by the template rendering
    // This is just a placeholder for the chart initialization
    // The actual data is rendered via Jinja2 template
}

/**
 * Handle tab selection retention using URL hash
 */
function handleTabSelection() {
    // Check for tabs
    const tabTriggers = document.querySelectorAll('a[data-bs-toggle="tab"]');
    if (tabTriggers.length === 0) return;
    
    // Get active tab from URL hash or use default
    const activeTab = window.location.hash || '#tab-default';
    
    // Activate the tab
    const tab = document.querySelector(`a[href="${activeTab}"]`);
    if (tab) {
        const tabInstance = new bootstrap.Tab(tab);
        tabInstance.show();
    }
    
    // Store active tab in URL hash when it changes
    tabTriggers.forEach(trigger => {
        trigger.addEventListener('shown.bs.tab', function (e) {
            window.location.hash = e.target.getAttribute('href');
        });
    });
}

/**
 * Animate stat cards with a fade-in effect
 */
function animateStatCards() {
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('animate-in');
        }, index * 100);
    });
}

/**
 * Initialize datepickers for date input fields
 */
function initDatepickers() {
    // This function would initialize datepickers if needed
    // Since we're using native HTML5 date inputs, this is not necessary
    // But the function is included for potential future enhancements
}

/**
 * Enable course filter functionality
 */
function enableCourseFilters() {
    const filterDropdown = document.getElementById('courseFilterDropdown');
    if (!filterDropdown) return;
    
    // This is handled by the server-side routing and template rendering
    // The function is included as a placeholder for potential client-side enhancements
}

/**
 * Update attendance stats
 * Called after a successful attendance marking or modification
 */
function updateAttendanceStats(presentCount, absentCount) {
    const presentElement = document.getElementById('present-count');
    const absentElement = document.getElementById('absent-count');
    const totalElement = document.getElementById('total-count');
    const presentPercentElement = document.getElementById('present-percentage');
    const absentPercentElement = document.getElementById('absent-percentage');
    
    if (presentElement) presentElement.textContent = presentCount;
    if (absentElement) absentElement.textContent = absentCount;
    
    const total = parseInt(presentCount) + parseInt(absentCount);
    if (totalElement) totalElement.textContent = total;
    
    const presentPercentage = total > 0 ? Math.round((presentCount / total) * 100) : 0;
    const absentPercentage = total > 0 ? Math.round((absentCount / total) * 100) : 0;
    
    if (presentPercentElement) presentPercentElement.textContent = `${presentPercentage}%`;
    if (absentPercentElement) absentPercentElement.textContent = `${absentPercentage}%`;
    
    // Update chart if it exists
    updateAttendanceChart(presentCount, absentCount);
}

/**
 * Update attendance chart with new data
 */
function updateAttendanceChart(presentCount, absentCount) {
    const chartElement = document.getElementById('attendanceChart');
    if (!chartElement) return;
    
    const chart = Chart.getChart(chartElement);
    if (chart) {
        chart.data.datasets[0].data = [presentCount, absentCount];
        chart.update();
    }
}

// Export functions for global use
window.dashboardFunctions = {
    updateAttendanceStats,
    updateAttendanceChart
};
